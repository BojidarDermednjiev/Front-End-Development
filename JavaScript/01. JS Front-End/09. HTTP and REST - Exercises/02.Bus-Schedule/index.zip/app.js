function solve() {
  const info = {
    departBtn: document.getElementById(`depart`),
    arriveBtn: document.getElementById(`arrive`),
    busInfo: document.querySelector(`.info`),
  };
  const API_URL = ` http://localhost:3030/jsonstore/bus/schedule/`;
  let busStopInfo = {
    name: ``,
    next: `depot`,
  };
  function depart() {
    fetch(`${API_URL}${busStopInfo.next}`)
      .then((res) => res.json())
      .then((busStop) => {
        busStopInfo = busStop;
        info.departBtn.disabled = true;
        info.arriveBtn.disabled = false;
        info.busInfo.textContent = `Next stop ${busStopInfo.name}`;
      });
  }

  async function arrive() {
    info.departBtn.disabled = false;
    info.arriveBtn.disabled = true;
    info.busInfo.textContent = `Arriving at ${busStopInfo.name}`;
  }

  return {
    depart,
    arrive,
  };
}

let result = solve();
